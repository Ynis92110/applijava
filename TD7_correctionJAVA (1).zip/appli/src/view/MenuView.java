package view;

import javax.swing.JFrame;
import javax.swing.JButton;

public class MenuView extends JFrame {

    public JButton btnJeu1;
    public JButton btnJeu2;
    public JButton btnJeu3;
    public JButton btnJeu4;

    public MenuView() {

        setTitle("Game Launcher");
        setSize(400,300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);

        btnJeu1 = new JButton("ShiFuMi");
        btnJeu1.setBounds(50,50,120,40);
        add(btnJeu1);

        btnJeu2 = new JButton("Devine le nombre");
        btnJeu2.setBounds(200,50,120,40);
        add(btnJeu2);

        btnJeu3 = new JButton("Bataille Navalle");
        btnJeu3.setBounds(50,120,120,40);
        add(btnJeu3);

        btnJeu4 = new JButton("Calculette");
        btnJeu4.setBounds(200,120,120,40);
        add(btnJeu4);
    }
}