package JEU;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.util.Random;

public class jeu1 extends JFrame {

    public jeu1() {

        setTitle("Jeu 1");
        setSize(300,200);
        setLocationRelativeTo(null);

        add(new JLabel("Bienvenue dans le Jeu 1", JLabel.CENTER));

        pierrePapierCiseaux(); // lancement du jeu
    }

    public void pierrePapierCiseaux() {

        String[] options = {"pierre", "papier", "ciseaux"};
        Random random = new Random(); // déclaré une seule fois ici

        boolean rejouer = true;

        while(rejouer) {

            String choixJoueur = JOptionPane.showInputDialog(
                    "Choisissez : pierre, papier ou ciseaux"
            );

            if (choixJoueur == null) return;

            choixJoueur = choixJoueur.toLowerCase();

            boolean valide = false;
            for(String option : options){
                if(option.equals(choixJoueur)){
                    valide = true;
                    break;
                }
            }

            if(!valide){
                JOptionPane.showMessageDialog(null,
                        "Choix invalide. Veuillez choisir entre pierre, papier ou ciseaux.");
                continue;
            }

            // choix aléatoire de l'ordinateur
            String choixOrdinateur = options[random.nextInt(options.length)];

            JOptionPane.showMessageDialog(null,"Vous avez choisi : " + choixJoueur);
            JOptionPane.showMessageDialog(null,"L'ordinateur a choisi : " + choixOrdinateur);

            if(choixJoueur.equals(choixOrdinateur)){
                JOptionPane.showMessageDialog(null,"Égalité !");
            }
            else if(
                    (choixJoueur.equals("pierre") && choixOrdinateur.equals("ciseaux")) ||
                    (choixJoueur.equals("papier") && choixOrdinateur.equals("pierre")) ||
                    (choixJoueur.equals("ciseaux") && choixOrdinateur.equals("papier"))
            ){
                JOptionPane.showMessageDialog(null,"Vous avez gagné !");
            }
            else{
                JOptionPane.showMessageDialog(null,"L'ordinateur a gagné !");
            }

            int choix = JOptionPane.showConfirmDialog(null,
                    "Voulez-vous rejouer ?");

            if(choix != JOptionPane.YES_OPTION){
                rejouer = false;
                JOptionPane.showMessageDialog(null,"Merci d'avoir joué !");
            }
        }
    }}