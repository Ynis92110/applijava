package JEU;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;

public class jeu4 extends JFrame {

    private JTextField affichage;
    private String operateur = "";
    private double memoire = 0;
    private boolean nouveauNombre = true;
    private boolean resultatAffiche = false;

    // Palette de couleurs
    private final Color BG_DARK      = new Color(18, 18, 24);
    private final Color BG_PANEL     = new Color(28, 28, 38);
    private final Color BTN_CHIFFRE  = new Color(42, 42, 58);
    private final Color BTN_OP       = new Color(255, 140, 0);
    private final Color BTN_FONC     = new Color(55, 55, 75);
    private final Color BTN_EGAL     = new Color(255, 100, 50);
    private final Color TEXTE_CLAIR  = new Color(255, 255, 255);
    private final Color TEXTE_GRIS   = new Color(180, 180, 200);
    private final Color ACCENT       = new Color(255, 140, 0);

    public jeu4() {
        setTitle("Jeu 4 - Calculatrice");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);
        getContentPane().setBackground(BG_DARK);
        setLayout(new BorderLayout(0, 0));

        // === AFFICHAGE ===
        JPanel panneauAffichage = new JPanel(new BorderLayout());
        panneauAffichage.setBackground(BG_DARK);
        panneauAffichage.setBorder(new EmptyBorder(30, 24, 10, 24));

        affichage = new JTextField("0") {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(BG_PANEL);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 16, 16);
                super.paintComponent(g);
                g2.dispose();
            }
        };
        affichage.setOpaque(false);
        affichage.setEditable(false);
        affichage.setHorizontalAlignment(SwingConstants.RIGHT);
        affichage.setFont(new Font("SansSerif", Font.BOLD, 42));
        affichage.setForeground(TEXTE_CLAIR);
        affichage.setCaretColor(ACCENT);
        affichage.setBorder(new EmptyBorder(18, 20, 18, 20));
        affichage.setPreferredSize(new Dimension(360, 90));

        panneauAffichage.add(affichage, BorderLayout.CENTER);
        add(panneauAffichage, BorderLayout.NORTH);

        // === BOUTONS ===
        JPanel grille = new JPanel(new GridLayout(5, 4, 10, 10));
        grille.setBackground(BG_DARK);
        grille.setBorder(new EmptyBorder(10, 24, 28, 24));

        String[][] labels = {
            { "C",   "±",   "%",   "÷"  },
            { "7",   "8",   "9",   "×"  },
            { "4",   "5",   "6",   "−"  },
            { "1",   "2",   "3",   "+"  },
            { "0",   ".",   "⌫",   "="  }
        };

        for (String[] ligne : labels) {
            for (String label : ligne) {
                grille.add(creerBouton(label));
            }
        }

        add(grille, BorderLayout.CENTER);

        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private JButton creerBouton(String label) {
        Color bg;
        Color fg = TEXTE_CLAIR;

        switch (label) {
            case "=":  bg = BTN_EGAL;    break;
            case "+": case "−": case "×": case "÷": bg = BTN_OP; break;
            case "C": case "±": case "%": case "⌫": bg = BTN_FONC; fg = TEXTE_GRIS; break;
            default: bg = BTN_CHIFFRE;
        }

        JButton btn = new JButton(label);
        btn.setFont(new Font("SansSerif", Font.BOLD, label.equals("0") ? 22 : 20));
        btn.setOpaque(false);
        btn.setContentAreaFilled(false);
        btn.setBorderPainted(false);
        btn.setFocusPainted(false);
        btn.setForeground(fg);
        btn.setPreferredSize(new Dimension(80, 70));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        btn.addActionListener(e -> gererAction(label));

        return btn;
    }

    private void gererAction(String cmd) {
        switch (cmd) {
            case "C":
                affichage.setText("0");
                operateur = "";
                memoire = 0;
                nouveauNombre = true;
                resultatAffiche = false;
                break;

            case "⌫":
                String s = affichage.getText();
                if (s.length() > 1) affichage.setText(s.substring(0, s.length() - 1));
                else affichage.setText("0");
                break;

            case "±":
                double v = Double.parseDouble(affichage.getText());
                affichage.setText(formater(-v));
                break;

            case "%":
                double pct = Double.parseDouble(affichage.getText()) / 100.0;
                affichage.setText(formater(pct));
                break;

            case "+": case "−": case "×": case "÷":
                memoire = Double.parseDouble(affichage.getText());
                operateur = cmd;
                nouveauNombre = true;
                resultatAffiche = false;
                break;

            case "=":
                double a = memoire;
                double b = Double.parseDouble(affichage.getText());
                double res = 0;
                switch (operateur) {
                    case "+": res = a + b; break;
                    case "−": res = a - b; break;
                    case "×": res = a * b; break;
                    case "÷":
                        if (b == 0) { affichage.setText("Erreur"); return; }
                        res = a / b; break;
                    default: return;
                }
                affichage.setText(formater(res));
                operateur = "";
                nouveauNombre = true;
                resultatAffiche = true;
                break;

            case ".":
                if (nouveauNombre) { affichage.setText("0."); nouveauNombre = false; }
                else if (!affichage.getText().contains(".")) affichage.setText(affichage.getText() + ".");
                break;

            default: // chiffres
                if (nouveauNombre || resultatAffiche) {
                    affichage.setText(cmd);
                    nouveauNombre = false;
                    resultatAffiche = false;
                } else {
                    String actuel = affichage.getText();
                    if (actuel.equals("0")) affichage.setText(cmd);
                    else if (actuel.length() < 12) affichage.setText(actuel + cmd);
                }
        }
    }

    private String formater(double d) {
        if (d == Math.floor(d) && !Double.isInfinite(d)) return String.valueOf((long) d);
        String s = String.format("%.8f", d).replaceAll("0+$", "").replaceAll("\\.$", "");
        return s;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(jeu4::new);
    }
}