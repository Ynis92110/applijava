package JEU;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

public class jeu3 extends JFrame {

    public jeu3() {

        setTitle("Jeu 3");
        setSize(300, 200);
        setLocationRelativeTo(null);

        add(new JLabel("Bienvenue dans le Jeu 3", JLabel.CENTER));

        batailleNavale(); // lancer le jeu
    }

    public void batailleNavale() {

        int[][] tabjoueur = new int[10][10];
        int pionPlaces = 0;
        int pionAPlacer = 5;

        // initialisation du tableau à 0
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
                tabjoueur[i][j] = 0;
            }
        }

        while (pionPlaces < pionAPlacer) {
            String inputLine = JOptionPane.showInputDialog(
                    "Pion " + (pionPlaces + 1) + "/" + pionAPlacer + "\n" +
                    "Entrez la ligne (0-9) :"
            );
            if (inputLine == null) return;

            String inputCol = JOptionPane.showInputDialog(
                    "Entrez la colonne (0-9) :"
            );
            if (inputCol == null) return;

            int line, column;

            try {
                line = Integer.parseInt(inputLine);
                column = Integer.parseInt(inputCol);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Entrée invalide ! Veuillez entrer un nombre entre 0 et 9.");
                continue;
            }

            if (line < 0 || line > 9 || column < 0 || column > 9) {
                JOptionPane.showMessageDialog(null, "Coordonnées invalides ! (0-9)");
                continue;
            }

            if (tabjoueur[line][column] == 0) {
                tabjoueur[line][column] = 1;
                pionPlaces++;
                JOptionPane.showMessageDialog(null, "Pion placé !\n" + afficherTableau(tabjoueur));
            } else {
                JOptionPane.showMessageDialog(null, "Case déjà occupée !");
            }
        }

        JOptionPane.showMessageDialog(null, "Tous les pions sont placés !");
    }

    // fonction pour afficher le tableau sous forme de texte
    private String afficherTableau(int[][] tableau) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
                sb.append(tableau[i][j]).append(" ");
            }
            sb.append("\n");
        }
        return sb.toString();
    }
}