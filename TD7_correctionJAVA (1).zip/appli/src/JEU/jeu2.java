package JEU;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.util.Random;

public class jeu2 extends JFrame {

    public jeu2() {

        setTitle("Jeu 2");
        setSize(300,200);
        setLocationRelativeTo(null);

        add(new JLabel("Bienvenue dans le Jeu 2", JLabel.CENTER));

        devineLeNombre(); // lancement du jeu
    }

    public void devineLeNombre() {
        Random random = new Random();
        int randomNumber = random.nextInt(100) + 1; // nombre aléatoire entre 1 et 100
        int attempts = 0;
        boolean gagne = false;

        while (!gagne) {
            String input = JOptionPane.showInputDialog(
                    "Devinez le nombre entre 1 et 100"
            );

            if (input == null) {
                JOptionPane.showMessageDialog(null, "Jeu annulé !");
                return;
            }

            int guess;

            try {
                guess = Integer.parseInt(input);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null,
                        "Veuillez entrer un nombre valide !");
                continue;
            }

            if (guess < 1 || guess > 100) {
                JOptionPane.showMessageDialog(null,
                        "Le nombre doit être entre 1 et 100 !");
                continue;
            }

            attempts++;

            if (guess == randomNumber) {
                JOptionPane.showMessageDialog(null,
                        "Bravo ! Vous avez deviné le nombre en " + attempts + " tentatives.");
                gagne = true;
            } else if (guess < randomNumber) {
                JOptionPane.showMessageDialog(null, "Le nombre est plus grand !");
            } else {
                JOptionPane.showMessageDialog(null, "Le nombre est plus petit !");
            }
        }
    }
}