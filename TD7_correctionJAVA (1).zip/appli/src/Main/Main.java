package Main;

import view.MenuView;
import controller.MenuController;

public class Main {

    public static void main(String[] args) {

        MenuView view = new MenuView();
        new MenuController(view);

        view.setVisible(true);
    }
}