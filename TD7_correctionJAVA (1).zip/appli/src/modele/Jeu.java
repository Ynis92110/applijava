package modele;



public class Jeu {

    private String nom;

    public Jeu(String nom) {
        this.nom = nom;
    }

    public String getNom() {
        return nom;
    }
}