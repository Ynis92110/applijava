package controller;



import view.MenuView;
import JEU.*;

public class MenuController {

    public MenuController(MenuView view) {

        view.btnJeu1.addActionListener(e -> {
            new jeu1().setVisible(true);
        });

        view.btnJeu2.addActionListener(e -> {
            new jeu2().setVisible(true);
        });

        view.btnJeu3.addActionListener(e -> {
            new jeu3().setVisible(true);
        });

        view.btnJeu4.addActionListener(e -> {
            new jeu4().setVisible(true);
        });

    }
}